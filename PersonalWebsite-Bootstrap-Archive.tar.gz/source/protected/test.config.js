module.exports = {
  env: "test",
  flask_api_origin: "http://127.0.0.1:5000",
  request_api_origin: "localhost:3000",
  codes: ["hey"]
};
